package com.example.weathertrack.repository;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.weathertrack.db.WeatherDao;
import com.example.weathertrack.db.WeatherDatabase;
import com.example.weathertrack.model.WeatherData;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.List;

public class WeatherRepository {
    private final WeatherDao weatherDao;

    public WeatherRepository(Context context) {
        WeatherDatabase db = WeatherDatabase.getInstance(context);
        this.weatherDao = db.weatherDao();
    }

    public void fetchAndSaveWeather(Context context) {
        try {
            InputStream is = context.getAssets().open("weather.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            String json = new String(buffer, "UTF-8");
            JSONObject obj = new JSONObject(json);

            long timestamp = System.currentTimeMillis();
            float temperature = (float) obj.getDouble("temperature");
            int humidity = obj.getInt("humidity");
            String condition = obj.getString("condition");

            WeatherData data = new WeatherData(timestamp, temperature, humidity, condition);
            new Thread(() -> weatherDao.insert(data)).start();
        } catch (Exception e) {
            Log.e("WeatherRepository", "Failed to fetch data", e);
        }
    }

    public LiveData<WeatherData> getLatestWeather() {
        return weatherDao.getLatestWeather();
    }

    public LiveData<List<WeatherData>> getLast7DaysWeather() {
        long sevenDaysAgo = System.currentTimeMillis() - 7 * 24 * 60 * 60 * 1000;
        return weatherDao.getWeatherFrom(sevenDaysAgo);
    }
}