package com.example.weathertrack;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.weathertrack.viewmodel.WeatherViewModel;
import com.example.weathertrack.model.WeatherData;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class MainActivity extends ComponentActivity {

    private WeatherViewModel viewModel;
    private TextView weatherText;
    private Button refreshButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weatherText = findViewById(R.id.weather_info);
        refreshButton = findViewById(R.id.btn_refresh);

        viewModel = new ViewModelProvider(this).get(WeatherViewModel.class);

        viewModel.getLatestWeather().observe(this, data -> {
            if (data != null) {
                String info = String.format(Locale.getDefault(),
                        "Temp: %.1f°C\nHumidity: %d%%\nCondition: %s\nTime: %s",
                        data.temperature,
                        data.humidity,
                        data.condition,
                        new SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
                                .format(data.timestamp)
                );
                weatherText.setText(info);
            } else {
                weatherText.setText("No data yet");
            }
        });

        refreshButton.setOnClickListener(v -> viewModel.fetchWeatherNow());
    }
}