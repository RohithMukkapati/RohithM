package com.example.weathertrack;

import android.app.Application;

import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.example.weathertrack.worker.WeatherWorker;

import java.util.concurrent.TimeUnit;

public class WeatherApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        PeriodicWorkRequest request =
                new PeriodicWorkRequest.Builder(WeatherWorker.class, 6, TimeUnit.HOURS)
                        .build();

        WorkManager.getInstance(this).enqueue(request);
    }
}