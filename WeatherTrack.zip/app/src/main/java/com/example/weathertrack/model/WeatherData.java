package com.example.weathertrack.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weather_data")
public class WeatherData {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public long timestamp;
    public float temperature;
    public int humidity;
    public String condition;

    public WeatherData(long timestamp, float temperature, int humidity, String condition) {
        this.timestamp = timestamp;
        this.temperature = temperature;
        this.humidity = humidity;
        this.condition = condition;
    }
}