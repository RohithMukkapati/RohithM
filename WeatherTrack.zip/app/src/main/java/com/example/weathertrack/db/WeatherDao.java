package com.example.weathertrack.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.weathertrack.model.WeatherData;

import java.util.List;

@Dao
public interface WeatherDao {
    @Insert
    void insert(WeatherData data);

    @Query("SELECT * FROM weather_data ORDER BY timestamp DESC LIMIT 1")
    LiveData<WeatherData> getLatestWeather();

    @Query("SELECT * FROM weather_data WHERE timestamp >= :fromTime ORDER BY timestamp ASC")
    LiveData<List<WeatherData>> getWeatherFrom(long fromTime);
}