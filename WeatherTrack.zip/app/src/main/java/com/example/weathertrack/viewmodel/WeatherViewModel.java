package com.example.weathertrack.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.weathertrack.model.WeatherData;
import com.example.weathertrack.repository.WeatherRepository;

import java.util.List;

public class WeatherViewModel extends AndroidViewModel {
    private final WeatherRepository repository;
    private final LiveData<WeatherData> latestWeather;
    private final LiveData<List<WeatherData>> weeklyWeather;

    public WeatherViewModel(@NonNull Application application) {
        super(application);
        repository = new WeatherRepository(application);
        latestWeather = repository.getLatestWeather();
        weeklyWeather = repository.getLast7DaysWeather();
    }

    public LiveData<WeatherData> getLatestWeather() {
        return latestWeather;
    }

    public LiveData<List<WeatherData>> getWeeklyWeather() {
        return weeklyWeather;
    }

    public void fetchWeatherNow() {
        repository.fetchAndSaveWeather(getApplication());
    }
}